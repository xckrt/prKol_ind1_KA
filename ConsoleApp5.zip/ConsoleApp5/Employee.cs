﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Employee
    {
        public string LastName;
        public string FirstName;
        public string MiddleName;
        public string Gender;
        public int Age;
        public decimal Salary;
    }
}
