﻿using ConsoleApp5;
//1
string inputFile = "input.txt";
string outputFile = "output.txt";


Stack<int> numbersStack = new Stack<int>();


try
{
    using (StreamReader reader = new StreamReader(inputFile))
    {
        string line;
        while ((line = reader.ReadLine()) != null)
        {
            if (int.TryParse(line, out int number))
            {
                numbersStack.Push(number);
            }
        }
        reader.Close();
    }
}
catch
{
    Console.WriteLine("Ошибка чтения файла");
    return;
}


try
{
    using (StreamWriter writer = new StreamWriter(outputFile))
    {
        while (numbersStack.Count > 0)
        {
            int number = numbersStack.Pop();
            writer.WriteLine(number);
        }
    }
    Console.WriteLine("Числа успешно записаны в файл " + outputFile);
}
catch
{
    Console.WriteLine("Ошибка записи файла:");

}


//8




//string inputFile = "employees.txt";

//Queue<Employee> youngerThan30 = new Queue<Employee>();
//Queue<Employee> olderThan30 = new Queue<Employee>();


//try
//{
//    using (StreamReader reader = new StreamReader(inputFile))
//    {
//        string line;
//        while ((line = reader.ReadLine()) != null)
//        {
//            string[] data = line.Split(' ');
//            if (data.Length == 6) 
//            {
//                Employee employee = new Employee
//                {
//                    LastName = data[0],
//                    FirstName = data[1],
//                    MiddleName = data[2],
//                    Gender = data[3],
//                    Age = int.Parse(data[4]),
//                    Salary = decimal.Parse(data[5])
//                };

//                if (employee.Age < 30)
//                    youngerThan30.Enqueue(employee);
//                else
//                    olderThan30.Enqueue(employee);
//            }
//            else
//            {
//                Console.WriteLine("Ошибка чтения строки: Неверный формат данных.");
//            }
//        }
//    }
//}
//catch (Exception e)
//{
//    Console.WriteLine("Ошибка чтения файла: " + e.Message);
//    return;
//}

//Console.WriteLine("Сотрудники младше 30 лет:");
//PrintEmployees(youngerThan30);


//Console.WriteLine("\nСотрудники старше или равные 30 лет:");
//PrintEmployees(olderThan30);


//    static void PrintEmployees(Queue<Employee> employees)
//{
//    foreach (var employee in employees)
//    {
//        Console.WriteLine($"{employee.LastName} {employee.FirstName} {employee.MiddleName}, {employee.Gender}, {employee.Age} лет, Зарплата: {employee.Salary}");
//    }
//}

